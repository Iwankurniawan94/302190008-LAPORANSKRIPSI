<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>{{ $title }}</title>
    <title>login</title>
    <!-- Favicon icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <!-- <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png" /> -->
    <!-- Custom CSS -->
    <link href="css/style.min.css" rel="stylesheet" />
</head>

<body class="">
    <div class="main-wrapper mt-5 p-5">
        <div class="row justify-content-center">
            <div class="col-4">
                <div class="auth-wrapper bg-dark p-4" style="border-radius: 10px;">
                    <!-- <div class="auth-box bg-dark"> -->
                    <div id="loginform">
                        <div class="text-center py-3">
                            <img src="img/logo-icon.png" alt="logo" />
                            <span class="text-white font-bold font-22 mt-4">
                                INVENTORY</span>
                        </div>
                        <!-- Form -->
                        <form class="form-horizontal mt-3" id="loginform" method="post" action="/login">
                            @csrf
                            <div class="row pb-4">
                                <div class="col-12">
                                    <div class=" border-top border-secondary pb-3"></div>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text bg-success text-white h-100"
                                                id="basic-addon1"><i class="bi bi-person-fill"></i></span>
                                        </div>
                                        <input name="username" autofocus id="username" type="text"
                                            class="form-control form-control-lg" placeholder="Username" autofocus
                                            required="" />
                                    </div>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text bg-warning text-white h-100"
                                                id="basic-addon2"><i class="bi bi-lock-fill"></i></span>
                                        </div>
                                        <input type="password" name="password" class="form-control form-control-lg"
                                            placeholder="Password" required="" />
                                    </div>
                                    <div class="border-top border-secondary"></div>
                                </div>
                            </div>
                            <div class="row" style="padding:0 10px">
                                <button class="btn btn-success text-white float-end" type="submit">
                                    Login
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

    </div>
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/bootstrap.bundle.min.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    @if (session()->has('gagal'))
        <script>
            Swal.fire({
                icon: 'error',
                showCancelButton: true,
                cancelButtonText: 'Ok',
                cancelButtonColor: '#3085d6',
                title: '{{ session('gagal') }}',
                showConfirmButton: false,
                // timer: 1500
            })
        </script>
    @endif
</body>

</html>
