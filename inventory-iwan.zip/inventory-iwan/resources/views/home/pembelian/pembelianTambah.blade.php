<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Tambah data pembelian</h2>

        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <form action="/pembelian" method="POST">
                    @csrf
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <label class="input-group-text" for="groupSelected">Kain</label>
                            <select class="form-select" name="kain_id" id="groupSelected" required="required" autofocus>
                                @foreach ($kain as $item)
                                    <option {{ old('kain_id') == $item->id_kain ? 'selected' : '' }}
                                        value="{{ $item->id_kain }}" required>
                                        {{ $item->nama_kain }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="harga_beli" required
                                class="form-control @error('harga_beli') is-invalid
                                @enderror"
                                id="harga_beli" placeholder="Nama Kain" value="{{ old('harga_beli') }}">
                            <label for="harga_beli">Harga beli kain per meter Rp.</label>
                            @error('harga_beli')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="jumlah" min="0" required
                                class="form-control @error('jumlah') is-invalid
                                @enderror"
                                id="jumlah" placeholder="jumlah Kain" value="{{ old('jumlah') }}">
                            <label for="jumlah">Jumlah kain m<sup>2</sup></label>
                            @error('jumlah')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="input-group mb-3">
                            <label class="input-group-text" for="kolega">Kolega</label>
                            <select class="form-select" name="kolega_id" id="kolega" required="required">
                                @foreach ($kolega as $item)
                                    <option {{ old('kolega_id') == $item->id_kolega ? 'selected' : '' }}
                                        value="{{ $item->id_kolega }}" required>
                                        {{ $item->nama_kolega }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="card-footer border-top">
                        <button class="btn btn-primary me-2" type="submit">Simpan</button>
                        <button class="btn btn-secondary" type="reset">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<x-footer></x-footer>
