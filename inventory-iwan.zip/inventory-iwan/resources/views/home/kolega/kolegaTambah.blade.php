<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Tambah data kolega</h2>

        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <form action="/kolega" method="POST">
                    <div class="card-body">
                        @csrf
                        <div class="form-floating mb-3">
                            <input type="text" name="nama_kolega" autofocus required
                                class="form-control @error('nama_kolega') is-invalid
                                @enderror"
                                id="nama_kolega" placeholder="Nama kolega" value="{{ old('nama_kolega') }}">
                            <label for="nama_kolega">Nama kolega</label>
                            @error('nama_kolega')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="telp" placeholder="Telepon" minlength="5" maxlength="20"
                                required
                                class="form-control @error('telp') is-invalid
                                @enderror"
                                id="telp"value="{{ old('telp') }}">
                            <label for="telp">Telepon</label>
                            @error('telp')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="alamat" placeholder="Alamat" minlength="5" maxlength="30"
                                required
                                class="form-control @error('alamat') is-invalid
                                @enderror"
                                id="alamat"value="{{ old('alamat') }}">
                            <label for="alamat">Alamat</label>
                            @error('alamat')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="card-footer border-top ">
                        <button class="btn btn-primary me-2" type="submit">Simpan</button>
                        <button class="btn btn-secondary" type="reset">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<x-footer></x-footer>
