<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Edit data kain</h2>

        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <form action="/kain/{{ $kain->id_kain }}" method="POST" enctype="multipart/form-data">
                    @method('put')
                    @csrf
                    <div class="card-body">
                        <div class="form-floating mb-3">
                            <input type="text" name="nama_kain" autofocus required
                                class="form-control @error('nama_kain') is-invalid
                                @enderror"
                                id="nama_kain" placeholder="Nama Kain" value="{{ old('nama_kain', $kain->nama_kain) }}">
                            <label for="nama_kain">Nama Kain</label>
                            @error('nama_kain')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="harga" min="0" required
                                class="form-control @error('harga') is-invalid
                                @enderror"
                                id="harga" placeholder="Harga Kain" value="{{ old('harga', $kain->harga) }}">
                            <label for="harga">Harga jual kain per meter Rp.</label>
                            @error('harga')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="jumlah" min="0" required
                                class="form-control @error('jumlah') is-invalid
                                @enderror"
                                id="jumlah" placeholder="Jumlah Kain" value="{{ old('jumlah', $kain->jumlah) }}">
                            <label for="jumlah">Jumlah Kain m<sup>2</sup></label>
                            @error('jumlah')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="input-group mb-3">
                            <label class="input-group-text" for="groupSelected">Palet</label>
                            <select class="form-select" name="penyimpanan_id" id="groupSelected" required="required">
                                @foreach ($penyimpanan as $item)
                                    <option {{ $kain->penyimpanan_id == $item->id_penyimpanan ? 'selected' : '' }}
                                        value="{{ $item->id_penyimpanan }}">
                                        {{ $item->palet }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="foto_sebelum" class="form-label">Gambar sebelumnya</label>
                            <input type="hidden" name="oldFotoSebelum" value="{{ $kain->foto_sebelum }}">
                            <input
                                class="form-control  @error('foto_sebelum') is-invalid
                                @enderror"
                                type="file" name="foto_sebelum" id="foto_sebelum">
                            @error('foto_sebelum')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        @php
                            inputText('desc_foto_sebelum', 'Deskripsi gambar sebelumnya', old('desc_foto_sebelum', $kain->desc_foto_sebelum) ?: '', $errors->first('desc_foto_sebelum') ?: '', 'text', '');
                        @endphp
                        <div class="mb-3">
                            <label for="foto_sesudah" class="form-label">Gambar setelahnya</label>
                            <input type="hidden" name="oldFotoSesudah" value="{{ $kain->foto_sesudah }}">
                            <input
                                class="form-control  @error('foto_sesudah') is-invalid
                                @enderror"
                                type="file" name="foto_sesudah" id="foto_sesudah">
                            @error('foto_sesudah')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        @php
                            inputText('desc_foto_sesudah', 'Deskripsi gambar sesudahnya', old('desc_foto_sesudah', $kain->desc_foto_sesudah) ?: '', $errors->first('desc_foto_sesudah') ?: '', 'text', '');
                        @endphp
                    </div>
                    <div class="card-footer border-top">
                        <button class="btn btn-primary me-2" type="submit">Update</button>
                        <button class="btn btn-secondary" type="reset">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<x-footer></x-footer>
