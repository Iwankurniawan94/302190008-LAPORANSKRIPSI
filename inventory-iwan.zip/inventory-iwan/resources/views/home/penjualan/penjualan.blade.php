<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">{{ $title }}</h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <div class="card-body">
                    <div class="mb-3">
                        @if (session()->has('gagal'))
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                <b><i class="bi bi-exclamation-triangle-fill"></i></b> {{ session('gagal') }}
                            </div>
                        @endif
                        @if (auth()->user()->status == 'admin' || auth()->user()->status == 'marketing')
                            <a class="btn btn-primary" title="Tambah data" href="/penjualan/create" role="button"><i
                                    class="bi bi-bookmark-plus"></i> Tambah</a>
                            <button type="button" class="btn btn-secondary" data-bs-toggle="modal"
                                data-bs-target="#suratJalan"><i class="bi bi-card-text"></i> Surat Jalan
                            </button>
                        @endif
                        <button type="button" class="btn btn-info" data-bs-toggle="modal"
                            data-bs-target="#cetakPenjualan" title="Laporan penjualan"><i
                                class="bi bi-file-earmark-text-fill"></i>
                            Laporan
                        </button>
                    </div>

                    <table id="autoTabel" class="table table-striped table-bordered border-dark">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th width="3%" class="text-white">No</th>
                                <th width="10%" class="text-white">Tanggal</th>
                                <th width="15%" class="text-white">Kain</th>
                                <th width="15%" class="text-white">Harga</th>
                                <th width="5%" class="text-white">Jumlah</th>
                                <th width="17%" class="text-white">Pembeli</th>
                                <th width="15%" class="text-white">Pencatat</th>
                                <th width="20%" class="text-white">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $jml = 0;
                            @endphp
                            @foreach ($penjualan as $item)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td class="text-center">{{ tanggal($item->tgl) }}</td>
                                    <td>{{ $item->kain->nama_kain }}</td>
                                    <td class="text-end">{{ rupiah($item->harga) }}</td>
                                    <td class="text-end">{{ $item->jumlah }} m<sup>2</sup></td>
                                    <td>{{ $item->nama_pembeli }}</td>
                                    <td>{{ $item->pengguna->nama }}</td>
                                    <td>
                                        @if (auth()->user()->status == 'admin' || auth()->user()->status == 'marketing')
                                            <a href="/penjualan/{{ $item->id_penjualan }}/edit" title="Edit data"
                                                class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                            <form action="/penjualan/{{ $item->id_penjualan }}" method="post"
                                                class="d-inline">
                                                @method('delete')
                                                @csrf
                                                <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                        class="bi bi-trash-fill"></i></button>
                                            </form>
                                        @endif
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                            data-bs-target="#detail{{ $item->id_penjualan }}" title="Detail">
                                            <i class="bi bi-card-list"></i>
                                        </button>
                                    </td>
                                </tr>
                                <div class="modal fade" id="detail{{ $item->id_penjualan }}" tabindex="-1"
                                    data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                    aria-labelledby="modalTitleId" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md"
                                        role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalTitleId">Detail penjualan</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-4">Pembeli</div>
                                                    <div class="col-8">: {{ $item->nama_pembeli }}</div>
                                                    <div class="col-4">Tanggal</div>
                                                    <div class="col-8">: {{ tanggal($item->tgl) }}</div>
                                                    <div class="col-4">Nama kain</div>
                                                    <div class="col-8">: {{ $item->kain->nama_kain }}</div>
                                                    <div class="col-4">Harga</div>
                                                    <div class="col-8">: {{ rupiah($item->harga) }}</div>
                                                    <div class="col-4">Quantity</div>
                                                    <div class="col-8">: {{ $item->jumlah }} m<sup>2</sup></div>
                                                    <div class="col-4">Total bayar</div>
                                                    <div class="col-8">:
                                                        {{ rupiah($item->jumlah * $item->harga) }}</div>
                                                    <div class="col-4">Pencatat transaksi</div>
                                                    <div class="col-8">: {{ $item->pengguna->nama }}</div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @php
                                    $jml += $item->jumlah * $item->harga;
                                @endphp
                            @endforeach
                        </tbody>
                    </table>
                    <h5>Total keseluruhan : {{ rupiah($jml) }} </h5>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
</div>

<!-- Surat jalan -->
<div class="modal fade" id="suratJalan" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
    role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitleId">Surat jalan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/penjualan/suratJalan" method="post" target="_blank">
                @csrf
                <div class="modal-body">
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="nama_pembeli">Nama pembeli</label>
                        <select class="form-select" name="nama_pembeli" id="nama_pembeli" required="required">
                            <option value="" selected hidden disabled>-Pembeli-</option>
                            @foreach ($pembeli as $i)
                                <option value="{{ $i['nama_pembeli'] }}">{{ $i['nama_pembeli'] }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-floating mb-3">
                        <textarea class="form-control" placeholder="alamat" name="alamat" id="alamat" required style="height: 100px"></textarea>
                        <label for="alamat">Alamat</label>
                    </div <div class="input-group mb-3">
                    <div class="form-floating mb-3">
                        <input type="date" name="awal" class="form-control " id="awal"
                            placeholder="Tanggal awal">
                        <label for="awal">Tanggal awal</label>
                    </div>
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="jalan">jalan</label>
                        <select class="form-select" name="jalan" id="jalan" required="required">
                            <option value="" selected hidden disabled>-Petugas-</option>
                            @php
                                $no = 0;
                            @endphp
                            @foreach ($jalan as $item)
                                <option value="{{ $no++ }}">{{ $item['supir'] }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <button type="submit" class="btn btn-primary">Cetak</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Optional: Place to the bottom of scripts -->
<script>
    const myModal = new bootstrap.Modal(document.getElementById('suratJalan'), options)
</script>
<div class="modal fade" id="cetakPenjualan" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
    role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitleId">Laporan penjualan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/penjualan/print" method="post" target="_blank">
                @csrf
                <div class="modal-body">
                    <div class="input-group mb-3">
                        <div class="form-floating mb-3">
                            <input type="date" name="awal" class="form-control " id="awal"
                                placeholder="Tanggal awal">
                            <label for="awal">Tanggal awal</label>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <div class="form-floating mb-3">
                            <input type="date" name="akhir" class="form-control " id="akhir"
                                placeholder="Tanggal akhir">
                            <label for="akhir">Tanggal akhir</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Reset</button>
                    <button type="submit" class="btn btn-primary">Print</button>
                </div>
            </form>
        </div>
    </div>
</div>

@component('components.footer')
@endcomponent
