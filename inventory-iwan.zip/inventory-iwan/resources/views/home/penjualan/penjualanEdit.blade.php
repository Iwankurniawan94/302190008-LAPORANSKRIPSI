<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">{{ $title }}</h2>

        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <form action="/penjualan/{{ $data->id_penjualan }}" method="POST">
                    @method('put')
                    @csrf
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <label class="input-group-text" for="groupSelected">Kain</label>
                            <select class="form-select" name="kain_id" id="groupSelected" required="required" disabled
                                autofocus>
                                @foreach ($kain as $item)
                                    <option {{ old('kain_id', $data->kain_id) == $item->id_kain ? 'selected' : '' }}
                                        value="{{ $item->id_kain }}" required>
                                        {{ $item->nama_kain . ' | ' . $item->harga }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="jumlah" min="0" required
                                class="form-control @error('jumlah') is-invalid
                                @enderror"
                                id="jumlah" placeholder="jumlah Kain" value="{{ old('jumlah', $data->jumlah) }}">
                            <label for="jumlah">Jumlah kain m<sup>2</sup></label>
                            @error('jumlah')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        {{ inputText('nama_pembeli', 'Nama pembeli', old('nama_pembeli', $data->nama_pembeli) ?: '', $errors->first('nama_pembeli') ?: '') }}
                    </div>
                    <div class="card-footer border-top">
                        <button class="btn btn-primary me-2" type="submit">Simpan</button>
                        <button class="btn btn-secondary" type="reset">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<x-footer></x-footer>
