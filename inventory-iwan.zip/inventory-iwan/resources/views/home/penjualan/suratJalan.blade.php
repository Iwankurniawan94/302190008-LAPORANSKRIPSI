<x-headerPrint>
    @slot('title')
        {{ $title }}
    @endslot
</x-headerPrint>

<div class="container">
    <header class="position-relative">
        <img src="/img/logo-kwangjin.png" width="75px" alt="Logo Inventori" class="position-absolute">
        <h3 class="text-center my-2">Surat Jalan</h3>
        <h4 class="text-center my-2">PT. Cemara Kwangjin Tekstil</h4>
        <div class="border-bottom border-1 border-dark"></div>
    </header>
    <main>
        <div class="row my-3">
            <div class="col-2">Tanggal</div>
            <div class="col-10">: {{ tanggal(date('Y-m-d')) }}</div>
            <div class="col-2">Jenis kendaraan</div>
            <div class="col-10">: {{ $mobil['mobil'] }}</div>
            <div class="col-2">No. polisi</div>
            <div class="col-10">: {{ $mobil['kode_polisi'] }}</div>
            <div class="col-2">Driver</div>
            <div class="col-10">: {{ $mobil['supir'] }}</div>
            <div class="col-2">Tujuan</div>
            <div class="col-10">
                : {{ $data[0]->nama_pembeli }}
                <p>{{ '  ' . $alamat }}</p>
            </div>
        </div>
        <p class="mb-2">Dikirimkan barang-barang sebagai berikut :</p>
        <table class="table-bordered border-1 border-dark">
            <thead>
                <tr>
                    <th>No </th>
                    <th>Nama kain</th>
                    <th>Qty</th>
                    <th>Harga</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $item)
                    <tr>
                        <td class="text-center">{{ $loop->iteration }}</td>
                        <td>{{ $item->kain->nama_kain }}</td>
                        <td class="text-end">{{ $item->jumlah }} m<sup>2</sup></td>
                        <td class="text-end">{{ rupiah($item->kain->harga) }} /m<sup>2</sup></td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="row mt-4">
            <div class="col-3">
                <p class="text-center" style="margin-bottom: 80px">
                    Gudang
                </p>
                <div class="border-bottom border-dark border-2 mb-3"></div>
            </div>
            <div class="col-3">
                <p class="text-center" style="margin-bottom: 80px">
                    Driver
                </p>
                <div class="border-bottom border-dark border-2 mb-3"></div>
            </div>
            <div class="col-3"></div>
            <div class="col-3">
                <p class="text-center" style="margin-bottom: 80px">
                    DIterima oleh
                </p>
                <div class="border-bottom border-dark border-2 mb-3"></div>
            </div>
        </div>
    </main>
</div>
<x-footerPrint></x-footerPrint>
