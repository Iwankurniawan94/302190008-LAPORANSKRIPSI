<x-headerPrint>
    @slot('title')
        {{ $title }}
    @endslot
</x-headerPrint>

<div class="container">
    <header class="pb-2 position-relative">
        <img src="/img/logo-kwangjin.png" width="75px" alt="Logo Inventori" class="position-absolute">
        <h2 class="text-center pt-4">Data Penjualan Kain</h2>
    </header>
    <div class="border-top border-2 border-dark mb-3"></div>
    <main>
        <table class="table-bordered border-1 border-dark">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>No </th>
                    <th>Tanggal</th>
                    <th>Pembeli</th>
                    <th>Kain</th>
                    <th>Qty</th>
                    <th>Harga</th>
                    <th>Total</th>
                    <th>Pencatat</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $jml = 0;
                @endphp
                @foreach ($data as $item)
                    <tr>
                        <td class="text-center">{{ $loop->iteration }}</td>
                        <td class="text-center">{{ tanggal($item->tgl) }}</td>
                        <td>{{ $item->nama_pembeli }}</td>
                        <td>{{ $item->kain->nama_kain }}</td>
                        <td class="text-end">{{ rupiah($item->harga) }}</td>
                        <td class="text-end">{{ $item->jumlah }}</td>
                        <td class="text-end">{{ rupiah($item->jumlah * $item->harga) }}</td>
                        <td>{{ $item->pengguna->nama }}</td>
                    </tr>
                    @php
                        $jml += $item->jumlah * $item->harga;
                    @endphp
                @endforeach
                <tr>
                    <th></th>
                    <th colspan="5">Total Keseluruhan</th>
                    <th class="text-end">{{ rupiah($jml) }}</th>
                    <th></th>
                </tr>
            </tbody>
        </table>

    </main>
</div>
<x-footerPrint />
