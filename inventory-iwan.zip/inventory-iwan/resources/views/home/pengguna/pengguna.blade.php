<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">{{ $title }}</h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <div class="card-body">
                    @if (session()->has('gagal'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                            <b><i class="bi bi-exclamation-triangle-fill"></i></b> {{ session('gagal') }}
                        </div>
                    @endif
                    {{-- @if (session()->has('pesan'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                <i class="bi bi-check-lg"></i> {{ session('pesan') }}
                            </div>
                        @endif --}}
                    @can('admin')
                        <a class="btn btn-primary mb-3" title="Tambah data" href="/pengguna/create" role="button"><i
                                class="bi bi-bookmark-plus"></i> Tambah</a>
                    @endcan
                    <table id="autoTabel" class="table table-striped table-bordered border-dark">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th width="3%" class="text-white">No</th>
                                <th width="20%" class="text-white">Nama</th>
                                <th width="15%" class="text-white">Username</th>
                                <th width="10%" class="text-white">Pasword</th>
                                <th width="20%" class="text-white">No. Telp</th>
                                <th width="20%" class="text-white">Status</th>
                                <th width="12%" class="text-white">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pengguna as $k)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $k->nama }}</td>
                                    <td>{{ $k->username }}</td>
                                    <td>{{ $k->password2 }}</td>
                                    <td>{{ $k->telp }}</td>
                                    <td>{{ $k->status }}</td>
                                    <td>
                                        <a href="/pengguna/{{ $k->id }}/edit" title="Edit data"
                                            class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                        <form action="/pengguna/{{ $k->id }}" method="post" class="d-inline">
                                            @method('delete')
                                            @csrf
                                            <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                    class="bi bi-trash-fill"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
</div>
<x-footer></x-footer>
