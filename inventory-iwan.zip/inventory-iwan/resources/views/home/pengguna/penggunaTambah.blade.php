<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Tambah data pengguna</h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <form action="/pengguna" method="POST">
                    <div class="card-body">
                        @csrf
                        @php
                            inputText('nama', 'Nama lengkap', old('nama') ?: '', $errors->first('nama') ?: '');
                        @endphp
                        <div class="form-floating mb-3">
                            <input type="text" name="username" placeholder="Username" minlength="5" maxlength="20"
                                required
                                class="form-control @error('username') is-invalid
                                @enderror"
                                id="username"value="{{ old('username') }}">
                            <label for="username">Username</label>
                            @error('username')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="password" placeholder="Password" minlength="5" maxlength="30"
                                required
                                class="form-control @error('password') is-invalid
                                @enderror"
                                id="password"value="{{ old('password') }}">
                            <label for="password">Password</label>
                            @error('password')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        @php
                            inputText('telp', 'Nomor telepon', old('telp') ?: '', $errors->first('telp') ?: '', 'number');
                        @endphp
                        <h6>Status pengguna</h6>
                        @php
                            inputRadio('status', 'Admin', 'admin', old('status') ?: '');
                        @endphp
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="status" id="marketing"
                                value="marketing" {{ old('status') == 'marketing' ? 'checked' : '' }}>
                            <label class="form-check-label" for="marketing">Marketing</label>
                        </div>
                        @php
                            inputRadio('status', 'Manajer', 'manajer', old('status') ?: '');
                        @endphp
                    </div>
                    <div class="card-footer">
                        <div class="mb-3">
                            <button class="btn btn-primary me-2" type="submit">Simpan</button>
                            <button class="btn btn-secondary" type="reset">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<x-footer></x-footer>
