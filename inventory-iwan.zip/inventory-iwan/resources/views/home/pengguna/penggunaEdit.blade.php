<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Edit data pengguna</h2>

        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <form action="/pengguna/{{ $pengguna->id }}" method="POST" enctype="multipart/form-data">
                    <div class="card-body">
                        @method('put')
                        @csrf
                        @php
                            inputText('nama', 'Nama lengkap', old('nama', $pengguna->nama) ?: '', $errors->first('nama') ?: '');
                        @endphp
                        <div class="form-floating mb-3">
                            <input type="text" name="username" placeholder="Username" minlength="5" maxlength="20"
                                required
                                class="form-control @error('username') is-invalid
                                @enderror"
                                id="username"value="{{ old('username', $pengguna->username) }}">
                            <label for="username">Username</label>
                            @error('username')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" name="password" placeholder="Password" minlength="5" maxlength="30"
                                required
                                class="form-control @error('password') is-invalid
                                @enderror"
                                id="password"value="{{ old('password', $pengguna->password2) }}">
                            <label for="password">Password</label>
                            @error('password')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" name="telp" placeholder="Nomor telepon" required
                                class="form-control @error('telp') is-invalid
                                @enderror"
                                id="telp"value="{{ old('telp', $pengguna->telp) }}">
                            <label for="telp">Nomor telepon</label>
                            @error('telp')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <h6>Status pengguna</h6>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="status" id="admin" value="admin"
                                required {{ old('status', $pengguna->status) != 'admin' ?: 'checked' }}>
                            <label class="form-check-label" for="admin">Admin</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="status" id="marketing"
                                value="marketing" {{ old('status', $pengguna->status) !== 'marketing' ?: 'checked' }}>
                            <label class="form-check-label" for="marketing">Marketing</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="status" id="manajer" value="manajer"
                                {{ old('status', $pengguna->status) !== 'manajer' ?: 'checked' }}>
                            <label class="form-check-label" for="manajer">Manajer</label>
                        </div>
                    </div>
                    <div class="card-footer border-top ">
                        <button class="btn btn-primary me-2" type="submit">Update</button>
                        <button class="btn btn-secondary" type="reset">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<x-footer></x-footer>
