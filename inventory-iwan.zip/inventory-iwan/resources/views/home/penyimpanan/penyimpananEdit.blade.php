<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Edit data penyimpanan</h2>

        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <form action="/penyimpanan/{{ $data->id_penyimpanan }}" method="POST">
                    <div class="card-body">
                        @method('put')
                        @csrf
                        <div class="form-floating mb-3">
                            <input type="text" name="palet" autofocus required
                                class="form-control @error('palet') is-invalid
                                @enderror"
                                id="palet" placeholder="Nama palet" value="{{ old('palet', $data->palet) }}">
                            <label for="palet">Nama palet</label>
                            @error('palet')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="input-group mb-3">
                            <label class="input-group-text" for="gedung">Gedung</label>
                            <select class="form-select" name="gedung" id="gedung" required="required">
                                {{-- <option value="" disabled selected hidden>-pilihan-</option> --}}
                                <option {{ old('gedung', $data->gedung) == 'Kain' ? 'selected' : '' }} value="Kain"
                                    required>Kain
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="card-footer border-top ">
                        <button class="btn btn-primary me-2" type="submit">Update</button>
                        <button class="btn btn-secondary" type="reset">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<x-footer></x-footer>
