<x-header>
    @slot('title')
        {{ $title }}
    @endslot
</x-header>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">{{ $title }}</h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <div class="card-body">
                    @can('admin')
                        <a class="btn btn-primary mb-3" title="Tambah data" href="/penyimpanan/create" role="button"><i
                                class="bi bi-bookmark-plus"></i> Tambah</a>
                    @endcan
                    <table id="autoTabel" class="table table-striped table-bordered border-dark">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th width="5%" class="text-white">No</th>
                                <th width="25%" class="text-white">Palet</th>
                                <th width="15%" class="text-white">Gedung</th>
                                @can('admin')
                                    <th width="15%" class="text-white">Pilihan</th>
                                @endcan
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $k)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $k->palet }}</td>
                                    <td>{{ $k->gedung }}</td>
                                    @can('admin')
                                        <td>
                                            <a href="/penyimpanan/{{ $k->id_penyimpanan }}/edit" title="Edit data"
                                                class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                            <form action="/penyimpanan/{{ $k->id_penyimpanan }}" method="post"
                                                class="d-inline">
                                                @method('delete')
                                                @csrf
                                                <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                        class="bi bi-trash-fill"></i></button>
                                            </form>
                                        </td>
                                    @endcan
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
</div>
@component('components.footer')
@endcomponent
