<footer class="footer text-center h6 text-black">
    &copy; Inventory {{ '2023' }}
</footer>
</div>
</main>
<!-- Bootstrap JavaScript Libraries -->
<script src="/js/jquery.min.js"></script>

<script src="/js/bootstrap.bundle.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="/js/perfect-scrollbar.jquery.min.js"></script>
<!--Wave Effects -->
<script src="/js/waves.js"></script>
<!--Menu sidebar -->
<script src="/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="/js/custom.min.js"></script>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#autoTabel').DataTable();
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
    $('.show_confirm').click(function(event) {
        let form = $(this).closest("form");
        let name = $(this).data("name");
        event.preventDefault();

        Swal.fire({
            title: 'Yakin hapus data ?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
</script>

@if (session()->has('pesan'))
    <script>
        Swal.fire({
            icon: 'success',
            // showCancelButton: true,
            // cancelButtonText: 'Ok',
            // cancelButtonColor: '#3085d6',
            // title: 'Sukses',
            // text: '{{ session('pesan') }}',
            position: 'top-end',
            // icon: 'success',
            title: '{{ session('pesan') }}',
            showConfirmButton: false,
            timer: 2000,
            toast: true,
        })
    </script>
@endif

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@yield('js-custom')
{{-- //rupiah --}}

</html>
