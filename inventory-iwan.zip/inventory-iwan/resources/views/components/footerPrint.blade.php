<footer>
    <!-- place footer here -->
</footer>
{{-- <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"></script> --}}
<script>
    const cetak = document.getElementById('print')
    cetak.addEventListener('click', () => {
        window.print()
    })
</script>
</body>

</html>
