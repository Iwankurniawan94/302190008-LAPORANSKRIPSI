<?php

use App\Http\Controllers\CHome;
use App\Http\Controllers\CKain;
use App\Http\Controllers\CGlobal;
use App\Http\Controllers\CKolega;
use App\Http\Controllers\CPengguna;
use App\Http\Controllers\CPembelian;
use App\Http\Controllers\CPenjualan;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CPenyimpanan;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


Route::controller(CGlobal::class)->group(function () {
    Route::get('/', 'index')->name('login')->middleware('guest');
    Route::post('/login', 'authenticate');
    Route::post('/logout', 'logout');
});

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [CHome::class, 'index']);

    Route::middleware('role:manajer,marketing,admin')->group(function () {
        Route::post('/pembelian/print', [CPembelian::class, 'print']);
        Route::post('/penjualan/print', [CPenjualan::class, 'print']);
        Route::get('/kain', [CKain::class, 'index']);
        Route::get('/penjualan', [CPenjualan::class, 'index']);
        Route::get('/pembelian', [CPembelian::class, 'index']);
        Route::get('/kolega', [CKolega::class, 'index']);

        Route::middleware('role:marketing,admin')->group(function () {
            Route::post('/penjualan/suratJalan', [CPenjualan::class, 'suratJalan']);
            Route::resource('/penjualan', CPenjualan::class)->except('show', 'index');
            Route::resource('/pembelian', CPembelian::class)->except('show', 'index');
            Route::get('/penyimpanan', [CPenyimpanan::class, 'index']);
        });
    });

    Route::middleware('admin')->group(function () {
        Route::resource('/kain', CKain::class)->except('show', 'index');
        Route::resource('/penyimpanan', CPenyimpanan::class)->except('show', 'index');
        Route::resource('/pengguna', CPengguna::class)->except('show');
        Route::resource('/kolega', CKolega::class)->except('show', 'index');
    });
});
