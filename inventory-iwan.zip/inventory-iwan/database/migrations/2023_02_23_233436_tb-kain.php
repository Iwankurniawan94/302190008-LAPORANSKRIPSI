<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class TbKain extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_kain', function (Blueprint $table) {
            $table->id('id_kain', 10);
            $table->text('nama_kain');
            $table->integer('harga');
            $table->integer('jumlah');
            $table->foreignId('penyimpanan_id');
            $table->text('foto_sebelum');
            $table->text('desc_foto_sebelum');
            $table->text('foto_sesudah');
            $table->text('desc_foto_sesudah');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
