<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Pembelian extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pembelian', function (Blueprint $table) {
            $table->id('id_pembelian');
            $table->date('tgl');
            $table->foreignId('kain_id')->references('id_kain')->on('tb_kain');
            $table->integer('harga_beli');
            $table->integer('jumlah');
            $table->foreignId('kolega_id')->references('id_kolega')->on('tb_kolega');
            $table->foreignId('pengguna_id')->references('id')->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
