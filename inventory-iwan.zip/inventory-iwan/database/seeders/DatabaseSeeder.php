<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        DB::table('users')->insert([
            'username' => 'admin',
            'password' => bcrypt('admin'),
            'password2' => 'admin',
            'nama' => 'Zaenudin Samsul',
            'telp' => '085333334444',
            'status' => 'admin',
        ]);

        DB::table('users')->insert([
            'username' => 'marketing',
            'password' => bcrypt('marketing'),
            'password2' => 'marketing',
            'nama' => 'Junaedi Ahmad',
            'telp' => '085322221111',
            'status' => 'marketing',
        ]);
        DB::table('users')->insert([
            'username' => 'manajer',
            'password' => bcrypt('manajer'),
            'password2' => 'manajer',
            'nama' => 'Feri',
            'telp' => '085322221111',
            'status' => 'manajer',
        ]);

        DB::table('tb_kain')->insert([
            'nama_kain' => 'Woll',
            'harga' => 20000,
            'jumlah' => 200,
            'penyimpanan_id' => 1,
            'foto_sebelum' => 'default-kain.jpg',
            'desc_foto_sebelum' => 'default image',
            'foto_sesudah' => 'default-kain.jpg',
            'desc_foto_sesudah' => 'default image',
        ]);
        DB::table('tb_kain')->insert([
            'nama_kain' => 'Cinos',
            'harga' => 15000,
            'jumlah' => 100,
            'penyimpanan_id' => 2,
            'foto_sebelum' => 'default-kain.jpg',
            'desc_foto_sebelum' => 'default image',
            'foto_sesudah' => 'default-kain.jpg',
            'desc_foto_sesudah' => 'default image',
        ]);

        DB::table('tb_kolega')->insert([
            'nama_kolega' => 'PT. Djarum',
            'telp' => '0852223331112',
            'alamat' => 'Jl. Adipatikertamanah dalam XII',
        ]);
        DB::table('tb_kolega')->insert([
            'nama_kolega' => 'Trans 7',
            'telp' => '08218321',
            'alamat' => 'Jl. Adipatikertamanah dalam X',
        ]);

        DB::table('tb_penjualan')->insert([
            'kain_id' => 1,
            'tgl' => date('Y-m-d'),
            'harga' => 100000,
            'jumlah' => 100,
            'nama_pembeli' => 'MNC',
            'pengguna_id' => 1,
        ]);
        DB::table('tb_penjualan')->insert([
            'kain_id' => 2,
            'tgl' => date('Y-m-d'),
            'harga' => 100000,
            'jumlah' => 100,
            'nama_pembeli' => 'MNC',
            'pengguna_id' => 2,
        ]);

        DB::table('tb_pembelian')->insert([
            'kain_id' => 1,
            'tgl' => date('Y-m-d'),
            'harga_beli' => 100000,
            'jumlah' => 100,
            'kolega_id' => 1,
            'pengguna_id' => 1,
        ]);
        DB::table('tb_pembelian')->insert([
            'kain_id' => 2,
            'tgl' => date('Y-m-d'),
            'harga_beli' => 100000,
            'jumlah' => 100,
            'kolega_id' => 2,
            'pengguna_id' => 2,
        ]);


        DB::table('tb_penyimpanan')->insert([
            'palet' => 'A',
            'gedung' => 'Kain'
        ]);
        DB::table('tb_penyimpanan')->insert([
            'palet' => 'B',
            'gedung' => 'Kain'
        ]);
    }
}
