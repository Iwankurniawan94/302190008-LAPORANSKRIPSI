<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MPenyimpanan extends Model
{
    use HasFactory;
    protected $table = 'tb_penyimpanan';
    protected $primaryKey = 'id_penyimpanan';
    protected $guard = 'id_penyimpanan';
    protected $fillable = ['palet', 'gedung'];
}
