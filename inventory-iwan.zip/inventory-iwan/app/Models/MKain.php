<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MKain extends Model
{
    use HasFactory;
    protected $table = 'tb_kain';
    protected $primaryKey = 'id_kain';
    protected $guard = 'id_kain';
    protected $fillable = ['nama_kain', 'harga', 'jumlah', 'penyimpanan_id', 'foto_sebelum', 'foto_sesudah', 'desc_foto_sebelum', 'desc_foto_sesudah'];

    public function penyimpanan()
    {
        return $this->belongsTo(MPenyimpanan::class, 'penyimpanan_id');
    }
}
