<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MKolega extends Model
{
    use HasFactory;
    protected $table = 'tb_kolega';
    protected $primaryKey = 'id_kolega';
    protected $guard = 'id_kolega';
    protected $fillable = ['nama_kolega', 'telp', 'alamat'];
}
