<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MPembelian extends Model
{
    use HasFactory;
    protected $table = 'tb_pembelian';
    protected $primaryKey = 'id_pembelian';
    protected $guard = 'id_pembelian';
    protected $fillable = ['tgl', 'kain_id', 'jumlah', 'harga_beli', 'kolega_id', 'pengguna_id'];

    public function kain()
    {
        return $this->belongsTo(MKain::class, 'kain_id');
    }
    public function kolega()
    {
        return $this->belongsTo(MKolega::class, 'kolega_id');
    }
    public function pengguna()
    {
        return $this->belongsTo(UserModel::class, 'pengguna_id', 'id');
    }
}
