<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MPenjualan extends Model
{
    use HasFactory;
    protected $table = 'tb_penjualan';
    protected $primaryKey = 'id_penjualan';
    protected $guard = 'id_penjualan';
    protected $fillable = ['tgl', 'kain_id', 'jumlah', 'harga', 'nama_pembeli', 'pengguna_id'];

    public function kain()
    {
        return $this->belongsTo(MKain::class, 'kain_id');
    }
    public function pengguna()
    {
        return $this->belongsTo(UserModel::class, 'pengguna_id', 'id');
    }
}
