<?php

namespace App\Http\Controllers;

use App\Models\MKolega;
use App\Models\MPembelian;
use App\Models\MKain;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CPembelian extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Data pembelian',
            'pembelian' => MPembelian::with('kain', 'kolega', 'pengguna')->get(),
        ];
        return view('home.pembelian.pembelian', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => 'Data pembelian',
            'kain' => MKain::all(),
            'kolega' => MKolega::all(),
        ];
        return view('home.pembelian.pembelianTambah', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $validasi = $request->validate([
            'kain_id' => 'required',
            'harga_beli' => 'numeric',
            'jumlah' => 'min:10|numeric',
            'kolega_id' => 'required',
        ]);
        $validasi['tgl'] = date('Y-m-d');
        $validasi['pengguna_id'] = auth()->user()->id;
        MPembelian::create($validasi);

        $jml = MKain::find($request->kain_id);
        MKain::where('id_kain', $request->kain_id)->update(['jumlah' => $jml->jumlah + $request->jumlah]);
        // dd($jml->jumlah + $request->jumlah);

        return redirect('/pembelian')->with('pesan', 'Data pembelian berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MPembelian  $mPembelian
     * @return \Illuminate\Http\Response
     */
    public function show(MPembelian $mPembelian)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MPembelian  $mPembelian
     * @return \Illuminate\Http\Response
     */
    public function edit(MPembelian $Pembelian)
    {
        // dd($Pembelian);
        $data = [
            'title' => 'Edit data pembelian',
            'data' => $Pembelian,
            'kain' => MKain::all(),
            'kolega' => MKolega::all(),
        ];
        return view('home.pembelian.pembelianEdit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MPembelian  $mPembelian
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MPembelian $Pembelian)
    {
        // dd($Pembelian, $request->all());
        $validasi = $request->validate([
            'kain_id' => 'required',
            'harga_beli' => 'numeric',
            'jumlah' => 'min:10|numeric',
            'kolega_id' => 'required',
        ]);
        $validasi['tgl'] = date('Y-m-d');
        $validasi['pengguna_id'] = auth()->user()->id;
        MPembelian::where('id_pembelian', $Pembelian->id_pembelian)->update($validasi);

        $jml = $request->jumlah - $Pembelian->jumlah;
        $kain = MKain::find($request->kain_id);
        MKain::where('id_kain', $request->kain_id)->update(['jumlah' => $kain->jumlah + $jml]);
        // dd($jml->jumlah + $request->jumlah);

        return redirect('/pembelian')->with('pesan', 'Data pembelian berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MPembelian  $mPembelian
     * @return \Illuminate\Http\Response
     */
    public function destroy(MPembelian $Pembelian)
    {
        // return $Pembelian;
        $kain = MKain::find($Pembelian->kain_id);
        MKain::where('id_kain', $Pembelian->kain_id)->update(['jumlah' => $kain->jumlah - $Pembelian->jumlah]);
        MPembelian::destroy($Pembelian->id_pembelian);
        return redirect('/pembelian')->with('pesan', 'Data pembelian berhasil di hapus');
    }

    public function print(Request $request)
    {
        $print = MPembelian::query();
        if ($request->awal)
            $print->whereDate('tgl', '>=', $request->awal);

        if ($request->akhir)
            $print->whereDate('tgl', '<=', $request->akhir);
        $print = $print->with('kain', 'kolega', 'pengguna')->orderBy('tgl', 'DESC')->get();
        // dd($print);
        $data = [
            'title' => 'print pembelian data pembelian',
            'data' => $print,
        ];
        return view('home.pembelian.pembelianPrint', $data);
    }
}
