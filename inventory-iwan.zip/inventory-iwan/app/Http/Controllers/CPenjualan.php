<?php

namespace App\Http\Controllers;

use App\Models\MKain;
use App\Models\MKolega;
use App\Models\MPenjualan;
use Illuminate\Http\Request;

class CPenjualan extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // return MPenjualan::with('kain', 'pengguna')->get();
        $data = [
            'pembeli' => MPenjualan::select('nama_pembeli')
                ->distinct()
                ->get(),
            'title' => 'Data penjualan',
            'penjualan' => MPenjualan::with('kain', 'pengguna')->get(),
            'jalan' => $this->jalan,
        ];
        // dd(MPenjualan::select('nama_pembeli')
        //     ->distinct()
        //     ->first());
        return view('home.penjualan.penjualan', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => 'Tambah penjualan',
            'kain' => MKain::all(),
        ];
        return view('home.penjualan.penjualanTambah', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $kain = MKain::find($request->kain_id);
        $validasi = $request->validate([
            'kain_id' => 'required',
            'jumlah' => 'max:' . $kain->jumlah . '|numeric',
            'nama_pembeli' => 'required',
        ]);
        $validasi['harga'] = $kain->harga;
        $validasi['tgl'] = date('Y-m-d');
        $validasi['pengguna_id'] = auth()->user()->id;
        MPenjualan::create($validasi);

        // $jml = MKain::find($request->kain_id);
        MKain::where('id_kain', $request->kain_id)->update(['jumlah' => $kain->jumlah - $request->jumlah]);
        // dd($jml->jumlah + $request->jumlah);

        return redirect('/penjualan')->with('pesan', 'Data penjualan berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MPenjualan  $mPenjualan
     * @return \Illuminate\Http\Response
     */
    public function show(MPenjualan $mPenjualan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MPenjualan  $mPenjualan
     * @return \Illuminate\Http\Response
     */
    public function edit(MPenjualan $penjualan)
    {
        // dd($penjualan);
        $data = [
            'title' => 'Edit data penjualan',
            'data' => $penjualan,
            'kain' => MKain::all(),
        ];
        return view('home.penjualan.penjualanEdit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MPenjualan  $mPenjualan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MPenjualan $penjualan)
    {
        // dd($penjualan);
        $kain = MKain::find($penjualan->kain_id);
        $validasi = $request->validate([
            // 'kain_id' => 'required',
            'jumlah' => 'min:1|max:' . $penjualan->jumlah + $kain->jumlah . '|numeric',
            'nama_pembeli' => 'required',
        ]);
        // $validasi['harga'] = $kain->harga;
        $validasi['tgl'] = date('Y-m-d');
        $validasi['pengguna_id'] = auth()->user()->id;
        MPenjualan::where('id_penjualan', $penjualan->id_penjualan)->update($validasi);

        $jml = $request->jumlah - $penjualan->jumlah;
        // $kain = MKain::find($penjualan->kain_id);
        MKain::where('id_kain', $penjualan->kain_id)->update(['jumlah' => $kain->jumlah - $jml]);
        return redirect('/penjualan')->with('pesan', 'Data penjualan berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MPenjualan  $mPenjualan
     * @return \Illuminate\Http\Response
     */
    public function destroy(MPenjualan $Penjualan)
    {
        // dd($Penjualan);
        MPenjualan::destroy($Penjualan->id_penjualan);
        return redirect('/penjualan')->with('pesan', 'Data penjualan berhasil di hapus');
    }

    protected $jalan = [
        [
            'mobil' => 'Fortuner',
            'supir' => 'Udin',
            'kode_polisi' => 'D5434XX'
        ],
        [
            'mobil' => 'Avanza',
            'supir' => 'Ferdi',
            'kode_polisi' => 'D5434YU'
        ],
        [
            'mobil' => 'Elef',
            'supir' => 'Yayat',
            'kode_polisi' => 'D5434PP'
        ],
    ];

    public function suratJalan(Request $request)
    {
        $print = MPenjualan::where('nama_pembeli', '=', $request->nama_pembeli);
        if ($request->awal)
            $print->whereDate('tgl', '>=', $request->awal);
        $print = $print->with('kain')->get();
        // dd($print[0]['tgl']);
        if (empty($print[0])) {
            $awal = tanggal($request->awal);
            return redirect('/penjualan')->with('gagal', "Tidak ada data pembeli $request->nama_pembeli pada tanggal $awal atau lebih");
        }

        $mobil = $this->jalan[$request->jalan];
        $data = [
            'title' => 'Cetak surat jalan',
            'data' => $print,
            'mobil' => $mobil,
            'alamat' => $request->alamat,
        ];
        return view('home.penjualan.suratJalan', $data);
    }

    public function print(Request $request)
    {
        $print = MPenjualan::query();
        if ($request->awal)
            $print->whereDate('tgl', '>=', $request->awal);

        if ($request->akhir)
            $print->whereDate('tgl', '<=', $request->akhir);
        $print = $print->with('kain', 'pengguna')->orderBy('tgl', 'DESC')->get();
        // dd($print);
        $data = [
            'title' => 'print data penjualan',
            'data' => $print,
        ];
        // dd($print);
        return view('home.penjualan.penjualanPrint', $data);
    }
}
