<?php

namespace App\Http\Controllers;

use App\Models\MKain;
use Illuminate\Support\Str;
use App\Models\MPenyimpanan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CKain extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Data kain',
            'kain' => MKain::with('penyimpanan')->get(),
        ];
        return view('home.kain.kain', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->authorize('admin');
        $data = [
            'title' => 'Tambah kain',
            'penyimpanan' => MPenyimpanan::all(),
        ];
        return view('home.kain.kainTambah', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'nama_kain' => 'max:50|min:2',
            'harga' => 'max:50',
            'jumlah' => 'max:20',
            'penyimpanan_id' => 'required',
            'foto_sebelum' => 'image|file',
            'foto_sesudah' => 'image|file',
        ]);
        if ($request->hasFile('foto_sebelum')) {
            $file = $request->file('foto_sebelum');
            $fileName = Str::random(15) . time() . '.' . $file->getClientOriginalExtension();
            // $validasi['foto_sebelum'] = $request->file('foto_sebelum')->store('gambar-sebelum');
            $file->storeAs('gambar-sebelum', $fileName);
            $validasi['foto_sebelum'] = $fileName;
            $validasi['desc_foto_sebelum'] = $request->desc_foto_sebelum ?: '';
        } else {
            $validasi['foto_sebelum'] = 'default-kain.jpg';
            $validasi['desc_foto_sebelum'] = 'default image';
        }
        if ($request->hasFile('foto_sesudah')) {
            $file = $request->file('foto_sesudah');
            $fileName = Str::random(15) . time() . '.' . $file->getClientOriginalExtension();
            // $validasi['foto_sesudah'] = $request->file('foto_sesudah')->store('gambar-sesudah');
            Storage::putFileAs('gambar-sesudah', $file, $fileName);
            $validasi['foto_sesudah'] = $fileName;
            $validasi['desc_foto_sesudah'] = $request->desc_foto_sesudah ?: '';
        } else {
            $validasi['foto_sesudah'] = 'default-kain.jpg';
            $validasi['desc_foto_sesudah'] = 'default image';
        }
        MKain::create($validasi);
        return redirect('/kain')->with('pesan', 'Data kain berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(MKain $kain)
    {
        // return MKain::find($idKain);
        $this->authorize('admin');
        $data = [
            'title' => 'Edit kain',
            'kain' => $kain,
            'penyimpanan' => MPenyimpanan::all(),
        ];
        return view('home/kain/kainEdit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $idKain)
    {
        // return $request->oldFotoSesudah . ' ' . $request->oldFotoSebelum;
        $validasi = $request->validate([
            'nama_kain' => 'max:50',
            'harga' => 'max:50',
            'jumlah' => 'max:20',
            'penyimpanan_id' => 'required',
            'foto_sebelum' => 'image|file',
            'foto_sesudah' => 'image|file',
        ]);
        if ($request->file('foto_sebelum')) {
            if ($request->oldFotoSebelum != 'default-kain.jpg') {
                $lokasiGambarSebelum = "gambar-sebelum/$request->oldFotoSebelum";
                if (Storage::exists($lokasiGambarSebelum)) {
                    Storage::delete($lokasiGambarSebelum);
                }
            }
            // $validasi['foto_sebelum'] = $request->file('foto_sebelum')->store('gambar-sebelum');
            $file = $request->file('foto_sebelum');
            $fileName = Str::random(15) . time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('gambar-sebelum', $fileName);
            $validasi['foto_sebelum'] = $fileName;
            $validasi['desc_foto_sebelum'] = $request->desc_foto_sebelum ?: '';
        }
        if ($request->file('foto_sesudah')) {
            if ($request->oldFotoSesudah != 'default-kain.jpg') {
                $lokasiGambarSesudah = "gambar-sesudah/$request->oldFotoSesudah";
                if (Storage::exists($lokasiGambarSesudah)) {
                    Storage::delete($lokasiGambarSesudah);
                }
            }
            // $validasi['foto_sesudah'] = $request->file('foto_sesudah')->store('gambar-sesudah');
            $file = $request->file('foto_sesudah');
            $fileName = Str::random(15) . time() . '.' . $file->getClientOriginalExtension();
            Storage::putFileAs('gambar-sesudah', $file, $fileName);
            $validasi['foto_sesudah'] = $fileName;
            $validasi['desc_foto_sesudah'] = $request->desc_foto_sesudah ?: '';
        }
        MKain::where('id_kain', $idKain)->update($validasi);
        return redirect('/kain')->with('pesan', 'Data kain berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(MKain $kain)
    {
        if ($kain->foto_sebelum != 'default-kain.jpg')
            Storage::delete($kain->foto_sebelum);
        if ($kain->foto_sesudah != 'default-kain.jpg')
            Storage::delete($kain->foto_sesudah);
        MKain::destroy($kain->id_kain);
        return redirect('/kain')->with('pesan', 'Data kain berhasil di hapus');
    }
}
