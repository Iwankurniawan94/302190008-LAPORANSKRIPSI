<?php

namespace App\Http\Controllers;

use App\Models\MPenyimpanan;
use Illuminate\Http\Request;

class CPenyimpanan extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Data penyimpanan',
            'data' => MPenyimpanan::all(),
        ];
        return view('home.penyimpanan.penyimpanan', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => 'Tambah penyimpanan',
        ];
        return view('home.penyimpanan.penyimpananTambah', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'palet' => 'required',
            'gedung' => 'required'
        ]);
        MPenyimpanan::create($validasi);
        return redirect('/penyimpanan')->with('pesan', 'Data penyimpanan berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MPenyimpanan  $mPenyimpanan
     * @return \Illuminate\Http\Response
     */
    public function show(MPenyimpanan $mPenyimpanan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MPenyimpanan  $mPenyimpanan
     * @return \Illuminate\Http\Response
     */
    public function edit(MPenyimpanan $penyimpanan)
    {
        // dd($penyimpanan);
        $data = [
            'title' => 'Tambah penyimpanan',
            'data' => $penyimpanan,
        ];
        return view('home.penyimpanan.penyimpananEdit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MPenyimpanan  $mPenyimpanan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MPenyimpanan $Penyimpanan)
    {
        $validasi = $request->validate([
            'palet' => 'required',
            'gedung' => 'required'
        ]);
        MPenyimpanan::where('id_penyimpanan', $Penyimpanan->id_penyimpanan)->update($validasi);
        return redirect('/penyimpanan')->with('pesan', 'Data penyimpanan berhasil di update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MPenyimpanan  $mPenyimpanan
     * @return \Illuminate\Http\Response
     */
    public function destroy(MPenyimpanan $Penyimpanan)
    {
        MPenyimpanan::destroy($Penyimpanan->id_penyimpanan);
        return redirect('/penyimpanan')->with('pesan', 'Data penyimpanan berhasil di hapus');
    }
}
