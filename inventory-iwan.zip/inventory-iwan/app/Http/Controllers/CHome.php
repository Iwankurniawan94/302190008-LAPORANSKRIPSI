<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\MKain;
use App\Models\MPembelian;
use App\Models\MPenjualan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Query\Grammars\MySqlGrammar;

class CHome extends Controller
{
    public function index()
    {
        $penjualan = MPenjualan::select(DB::raw('MONTH(tgl) as bulan, YEAR(tgl) as tahun, SUM(harga) as total'))
            ->groupBy('bulan', 'tahun')->orderBy('tahun', 'desc')->orderBy('bulan', 'asc')
            ->take(5)->get()
            ->map(function ($item) {
                $item->bulan = strftime('%B', mktime(0, 0, 0, $item->bulan, 1)) . ' ' . $item->tahun;
                return $item;
            });
        $pembelian = MPembelian::select(DB::raw('MONTH(tgl) as bulan, YEAR(tgl) as tahun, SUM(harga_beli) as total'))
            ->groupBy('bulan', 'tahun')->orderBy('tahun', 'desc')->orderBy('bulan', 'asc')
            ->take(5)->get()
            ->map(function ($item) {
                $item->bulan = strftime('%B', mktime(0, 0, 0, $item->bulan, 1)) . ' ' . $item->tahun;
                return $item;
            });
        // dd($pembelian);
        $data = [
            'title' => 'Dashboard',
            'kain' => MKain::all(),
            'penjualan' => $penjualan,
            'pembelian' => $pembelian,
            'penjualanTerakhir' => MPenjualan::with('kain')->orderBy('tgl', 'DESC')->take(5)->get(),
            'pembelianTerakhir' => MPembelian::with('kain')->orderBy('tgl', 'DESC')->take(5)->get(),
        ];
        return view('home.dashboard', $data);
    }
}
