<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use NumberFormatter;

class CGlobal extends Controller
{
    public function index()
    {
        // $n = 1000000;
        // $f = new NumberFormatter('id_ID', NumberFormatter::SPELLOUT);
        $data = [
            'title' => 'Login',
            'desc' => 'Silahkan login',
            // 'no' => $f->format($n),
        ];
        return view('global/login', $data);
    }

    public function authenticate(Request $req)
    {
        $credentials = $req->validate([
            // 'email' => 'email:dns',
            'username' => 'required',
            'password' => 'required'
        ]);
        // dd($req);

        if (Auth::attempt($credentials)) {
            $req->session()->regenerate();
            // return  auth()->user()->nama;
            return redirect()->intended('/dashboard');
        }

        return back()->with('gagal', 'Login gagal');
    }

    public function logout(Request $req)
    {
        Auth::logout();
        $req->session()->invalidate();
        $req->session()->regenerateToken();
        return redirect('/');
    }
}
