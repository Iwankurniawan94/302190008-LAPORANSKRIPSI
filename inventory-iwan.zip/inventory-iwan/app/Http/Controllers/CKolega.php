<?php

namespace App\Http\Controllers;

use App\Models\MKolega;
use Illuminate\Http\Request;

class CKolega extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'title' => 'Data Kolega',
            'kolega' => MKolega::all(),
        ];
        return view('home.kolega.kolega', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => 'Tambah kolega',
        ];
        return view('home.kolega.kolegaTambah', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'nama_kolega' => 'required',
            'telp' => 'min:10|max:15',
            'alamat' => 'required',
        ]);
        MKolega::create($validasi);
        return redirect('/kolega')->with('pesan', 'Data kolega berhasil di tambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MKolega  $mKolega
     * @return \Illuminate\Http\Response
     */
    public function show(MKolega $mKolega)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MKolega  $mKolega
     * @return \Illuminate\Http\Response
     */
    public function edit(MKolega $Kolega)
    {
        // dd($Kolega);
        $data = [
            'title' => 'Edit kain',
            'data' => $Kolega,
        ];
        return view('home.kolega.kolegaEdit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MKolega  $mKolega
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MKolega $Kolega)
    {
        // dd($Kolega);

        $validasi = $request->validate([
            'nama_kolega' => 'required',
            'telp' => 'min:10|max:15',
            'alamat' => 'required',
        ]);
        MKolega::where('id_kolega', $Kolega->id_kolega)->update($validasi);
        return redirect('/kolega')->with('pesan', 'Data kolega berhasil di tambah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MKolega  $mKolega
     * @return \Illuminate\Http\Response
     */
    public function destroy(MKolega $Kolega)
    {
        // dd($Kolega);

        MKolega::destroy($Kolega->id_kolega);
        return redirect('/kolega')->with('pesan', 'Data kolega berhasil di hapus');
    }
}
