<?php
function rupiah($uang)
{
    $rp = number_format($uang, 0, ',', '.');
    return "Rp. " . $rp;
}

function tanggal($date)
{
    return date('d/M/Y', strtotime($date));
}

function nav($url, $label, $icon)
{ ?>
    <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" href="<?= $url ?>" aria-expanded="false" title="<?= $label ?>">
        <i class="bi <?= $icon ?>"></i><span class="hide-menu"><?= $label ?></span>
    </a>
<?php
}

function inputText($name, $label, $old = '', $error = '', $type = 'text', $required = 'required')
{
?>
    <div class="form-floating mb-3">
        <input type="<?= $type ?>" name="<?= $name ?>" placeholder="<?= $label ?>" minlength="2" autofocus <?= $required ?> class="form-control <?= $error ? 'is-invalid' : '' ?> " id="<?= $name ?>" value="<?= $old ?>">
        <label for="<?= $name ?>"><?= $label ?></label>
        <?php if ($error) : ?>
            <div class="invalid-feedback">
                <?= $error ?>
            </div>
        <?php endif; ?>
    </div>
<?php
}

function inputRadio($name, $label, $val, $old = '')
{
?>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="<?= $name ?>" id="<?= $val ?>" value="<?= $val ?>" required <?= $old == $val ? 'checked' : '' ?>>
        <label class="form-check-label" for="<?= $val ?>"><?= $label ?></label>
    </div>
<?php
}

function selectRelasi($name, $label, $relasi, $old = '', $relID = '', $relTampil = '')
{
    // dd($relasi);
?>
    <div class="input-group mb-3">
        <label class="input-group-text" for="<?= $name ?>"><?= $label ?></label>
        <select class="form-select" name="<?= $name ?>" id="<?= $name ?>" required="required">
            <?php
            foreach ($relasi as $item) {
            ?>
                <option <?= $old == $item->$relID ? 'selected' : '' ?> value="<?= $item->$relID ?>">
                    <?= $item->$relTampil ?>
                </option>
            <?php } ?>
        </select>
    </div>
<?php
}

function minKata($text, $limit)
{
    $words = explode(' ', $text);
    $result = '';
    foreach ($words as $w) {
        if (strlen($result) + strlen($w) <= $limit) {
            $result .= $w . ' ';
        } else {
            break;
        }
    }
    return trim($result);
}
