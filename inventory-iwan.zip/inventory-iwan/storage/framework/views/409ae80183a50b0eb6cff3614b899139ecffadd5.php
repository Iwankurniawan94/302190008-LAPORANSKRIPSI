<nav class="sidebar-nav">
    <ul id="sidebarnav" class="pt-4">
        <li class="sidebar-item">
            <?php echo nav('/dashboard', 'Dashboard', 'bi-columns'); ?>

        </li>
        <li
            class="sidebar-item <?php echo e(request()->segment(1) == 'pembelian' || request()->is('penjualan*') ? 'selected' : ''); ?>">
            <a class="sidebar-link has-arrow waves-effect waves-dark text-decoration-none" href="javascript:void(0)"
                aria-expanded="false" title="Laporan"><i class="bi bi-file-earmark-text-fill"></i><span
                    class="hide-menu">Transaksi
                </span></a>
            <ul aria-expanded="false" class="collapse first-level">
                <li class="sidebar-item">
                    <a href="/pembelian" class="sidebar-link ms-4" title="Pembelian"><i
                            class="bi bi-cash-stack"></i><span class="hide-menu"> Pembelian
                        </span></a>
                </li>
                <li class="sidebar-item">
                    <a href="/penjualan" class="sidebar-link ms-4" title="Penjualan"><i
                            class="bi bi-cash-coin"></i><span class="hide-menu"> Penjualan </span></a>
                </li>
            </ul>
        </li>
        <li class="sidebar-item <?php echo e(request()->is('kain*') ? 'selected' : ''); ?>">
            <?php echo nav('/kain', 'Kain', 'bi-collection-fill'); ?>

        </li>
        <?php if(auth()->user()->status == 'admin' || auth()->user()->status == 'marketing'): ?>
            <li class="sidebar-item <?php echo e(request()->segment(1) == 'penyimpanan' ? 'selected' : ''); ?>">
                <?php echo nav('/penyimpanan', 'Penyimpanan', 'bi-house'); ?>

            </li>
        <?php endif; ?>

        <li class="sidebar-item <?php echo e(request()->segment(1) == 'kolega' ? 'selected' : ''); ?>">
            <?php echo nav('/kolega', 'Kolega', 'bi-person-vcard-fill'); ?>

        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
            <li class="sidebar-item <?php echo e(request()->segment(1) == 'pengguna' ? 'selected' : ''); ?>">
                <?php echo nav('/pengguna', 'Pengguna', 'bi-people-fill'); ?>

            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/components/nav.blade.php ENDPATH**/ ?>