<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
        <?php echo e($title); ?>

    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title">Dashboard <?php echo e(auth()->user()->status); ?></h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3">
                <div class="card-body">
                    <h4 class="card-title">Stok Kain</h4>
                    <canvas id="myChart" height="70"></canvas>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
    

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-warning">
                    <h4>Transaksi penjualan terbaru</h4>
                </div>
                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <th>Tanggal</th>
                            <th>Kain</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $penjualanTerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e(tanggal($i->tgl)); ?></td>
                                    <td><?php echo e($i->kain->nama_kain); ?></td>
                                    <td class="text-end"><?php echo e($i->jumlah); ?> m<sup>2</sup></td>
                                    <td class="text-end"><?php echo e(rupiah($i->jumlah * $i->kain->harga)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Card -->
        </div>
        <div class="col-md-6">
            <!-- card -->
            <div class="card">
                <div class="card-header bg-cyan">
                    <h4>Transaksi pembelian terbaru</h4>
                </div>
                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <th>Tanggal</th>
                            <th>Kain</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pembelianTerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e(tanggal($i->tgl)); ?></td>
                                    <td><?php echo e($i->kain->nama_kain); ?></td>
                                    <td class="text-end"><?php echo e($i->jumlah); ?> m<sup>2</sup></td>
                                    <td class="text-end"><?php echo e(rupiah($i->jumlah * $i->kain->harga)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- card new -->
        </div>
    </div>
</div>

<script>
    const kain = <?= json_encode($kain) ?>;
    const penjualan = <?= json_encode($penjualan) ?>;
    const pembelian = <?= json_encode($pembelian) ?>;
    const numData = kain.length
</script>


<?php $__env->startSection('js-custom'); ?>
    <script>
        // grafik(penjualan, 'grafikPenjualan', 'Penjualan');
        // grafik(pembelian, 'grafikPembelian', 'Pembelian', 'brown');

        function grafik(arr = [], id = '', tema = '', bg = 'green') {
            var labels = [];
            var data = [];
            arr.forEach(function(item) {
                labels.push(item['bulan']);
                data.push(item['total']);
            });

            const ctx = document.querySelector('#' + id);
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Total ' + tema,
                        data: data,
                        borderWidth: 1,
                        backgroundColor: bg,
                        borderColor: 'gray',
                        pointRadius: 5
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                }
            });
        }


        var bat = document.getElementById('myChart');
        var namaKain = [];
        var jml = [];

        kain.forEach(function(item) {
            namaKain.push(item['nama_kain']);
            jml.push(item['jumlah']);
        });

        // Fungsi untuk menghasilkan skema warna acak dengan tingkat transparansi 50%
        function generateRandomColor() {
            const randomColor = 'rgba(' + Math.floor(Math.random() * 256) + ', ' + Math.floor(Math.random() * 256) + ', ' +
                Math.floor(Math.random() * 256) + ', 0.5)';
            return randomColor;
        }

        const colorPalette = [];


        // Membuat skema warna acak dengan tingkat transparansi 50%
        for (let i = 0; i < numData; i++) {
            colorPalette.push(generateRandomColor());
        }

        new Chart(bat, {
            type: 'bar',
            data: {
                labels: namaKain,
                datasets: [{
                    label: '# Stok kain',
                    data: jml,
                    backgroundColor: colorPalette,
                    borderWidth: 1,
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/dashboard.blade.php ENDPATH**/ ?>