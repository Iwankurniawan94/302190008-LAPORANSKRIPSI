<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.headerPrint','data' => []]); ?>
<?php $component->withName('headerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
        <?php echo e($title); ?>

    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="container">
    <header class="position-relative">
        <img src="/img/logo-kwangjin.png" width="75px" alt="Logo Inventori" class="position-absolute">
        <h3 class="text-center my-2">Surat Jalan</h3>
        <h4 class="text-center my-2">PT. Cemara Kwangjin Tekstil</h4>
        <div class="border-bottom border-1 border-dark"></div>
    </header>
    <main>
        <div class="row my-3">
            <div class="col-2">Tanggal</div>
            <div class="col-10">: <?php echo e(tanggal(date('Y-m-d'))); ?></div>
            <div class="col-2">Jenis kendaraan</div>
            <div class="col-10">: <?php echo e($mobil['mobil']); ?></div>
            <div class="col-2">No. polisi</div>
            <div class="col-10">: <?php echo e($mobil['kode_polisi']); ?></div>
            <div class="col-2">Driver</div>
            <div class="col-10">: <?php echo e($mobil['supir']); ?></div>
            <div class="col-2">Tujuan</div>
            <div class="col-10">
                : <?php echo e($data[0]->nama_pembeli); ?>

                <p><?php echo e('  ' . $alamat); ?></p>
            </div>
        </div>
        <p class="mb-2">Dikirimkan barang-barang sebagai berikut :</p>
        <table class="table-bordered border-1 border-dark">
            <thead>
                <tr>
                    <th>No </th>
                    <th>Nama kain</th>
                    <th>Qty</th>
                    <th>Harga</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->kain->nama_kain); ?></td>
                        <td class="text-end"><?php echo e($item->jumlah); ?> m<sup>2</sup></td>
                        <td class="text-end"><?php echo e(rupiah($item->kain->harga)); ?> /m<sup>2</sup></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row mt-4">
            <div class="col-3">
                <p class="text-center" style="margin-bottom: 80px">
                    Gudang
                </p>
                <div class="border-bottom border-dark border-2 mb-3"></div>
            </div>
            <div class="col-3">
                <p class="text-center" style="margin-bottom: 80px">
                    Driver
                </p>
                <div class="border-bottom border-dark border-2 mb-3"></div>
            </div>
            <div class="col-3"></div>
            <div class="col-3">
                <p class="text-center" style="margin-bottom: 80px">
                    DIterima oleh
                </p>
                <div class="border-bottom border-dark border-2 mb-3"></div>
            </div>
        </div>
    </main>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footerPrint','data' => []]); ?>
<?php $component->withName('footerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/penjualan/suratJalan.blade.php ENDPATH**/ ?>