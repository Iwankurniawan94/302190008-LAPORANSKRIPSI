<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
        <?php echo e($title); ?>

    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title"><?php echo e($title); ?></h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <div class="card-body">
                    <?php if(auth()->user()->status == 'admin' || auth()->user()->status == 'marketing'): ?>
                        <a class="btn btn-primary mb-3 mt-3" title="Tambah data" href="/pembelian/create"
                            role="button"><i class="bi bi-bookmark-plus"></i> Tambah</a>
                    <?php endif; ?>
                    <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#cetakPembelian"
                        title="Laporan pembelian"><i class="bi bi-file-earmark-text-fill"></i>
                        Laporan
                    </button>
                    <table id="autoTabel" class="table table-striped table-bordered border-dark">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th width="3%" class="text-white">No</th>
                                <th width="12%" class="text-white">Tanggal</th>
                                <th width="13%" class="text-white">Kain</th>
                                <th width="13%" class="text-white">Harga</th>
                                <th width="4%" class="text-white">Jumlah</th>
                                <th width="15%" class="text-white">Total</th>
                                <th width="15%" class="text-white">Kolega</th>
                                <th width="20%" class="text-white">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $jml = 0;
                            ?>
                            <?php $__currentLoopData = $pembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(tanggal($item->tgl)); ?></td>
                                    <td><?php echo e($item->kain->nama_kain); ?></td>
                                    <td class="text-end"><?php echo e(rupiah($item->harga_beli)); ?></td>
                                    <td class="text-end"><?php echo e($item->jumlah); ?> m<sup>2</sup></td>
                                    <td class="text-end"><?php echo e(rupiah($item->jumlah * $item->harga_beli)); ?></td>
                                    <td><?php echo e($item->kolega->nama_kolega); ?></td>
                                    <td>
                                        <?php if(auth()->user()->status == 'admin' || auth()->user()->status == 'marketing'): ?>
                                            <a href="/pembelian/<?php echo e($item->id_pembelian); ?>/edit" title="Edit data"
                                                class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                            <form action="/pembelian/<?php echo e($item->id_pembelian); ?>" method="post"
                                                class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                        class="bi bi-trash-fill"></i></button>
                                            </form>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                            data-bs-target="#detail<?php echo e($item->id_pembelian); ?>" title="Detail">
                                            <i class="bi bi-card-list"></i>
                                        </button>
                                    </td>
                                </tr>
                                <div class="modal fade" id="detail<?php echo e($item->id_pembelian); ?>" tabindex="-1"
                                    data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                    aria-labelledby="modalTitleId" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md"
                                        role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalTitleId">Detail pembelian</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-4">Kolega</div>
                                                    <div class="col-8">: <?php echo e($item->kolega->nama_kolega); ?></div>
                                                    <div class="col-4">Tanggal</div>
                                                    <div class="col-8">: <?php echo e(tanggal($item->tgl)); ?></div>
                                                    <div class="col-4">Nama kain</div>
                                                    <div class="col-8">: <?php echo e($item->kain->nama_kain); ?></div>
                                                    <div class="col-4">Harga</div>
                                                    <div class="col-8">: <?php echo e(rupiah($item->harga_beli)); ?></div>
                                                    <div class="col-4">Quantity</div>
                                                    <div class="col-8">: <?php echo e($item->jumlah); ?> m<sup>2</sup></div>
                                                    <div class="col-4">Total bayar</div>
                                                    <div class="col-8">:
                                                        <?php echo e(rupiah($item->jumlah * $item->harga_beli)); ?></div>
                                                    <div class="col-4">Pencatat transaksi</div>
                                                    <div class="col-8">: <?php echo e($item->pengguna->nama); ?></div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    $jml += $item->jumlah * $item->harga_beli;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                    <h5>Total keseluruhan : <?php echo e(rupiah($jml)); ?> </h5>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
</div>

<div class="modal fade" id="cetakPembelian" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
    role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitleId">Laporan pembelian</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/pembelian/print" method="post" target="_blank">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="input-group mb-3">
                        <div class="form-floating mb-3">
                            <input type="date" name="awal" class="form-control " id="awal"
                                placeholder="Tanggal awal">
                            <label for="awal">Tanggal awal</label>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <div class="form-floating mb-3">
                            <input type="date" name="akhir" class="form-control " id="akhir"
                                placeholder="Tanggal akhir">
                            <label for="akhir">Tanggal akhir</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Reset</button>
                    <button type="submit" class="btn btn-primary">Print</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startComponent('components.footer'); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/pembelian/pembelian.blade.php ENDPATH**/ ?>