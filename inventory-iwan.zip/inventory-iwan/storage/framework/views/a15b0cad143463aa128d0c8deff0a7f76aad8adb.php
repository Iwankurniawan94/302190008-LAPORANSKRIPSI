<nav class="sidebar-nav">
    <ul id="sidebarnav" class="pt-4">
        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" href="/dashboard"
                aria-expanded="false" title="Dashboard"><i class="bi bi-columns"></i><span
                    class="hide-menu">Dashboard</span></a>
        </li>
        <li class="sidebar-item">
            <a class="sidebar-link has-arrow waves-effect waves-dark text-decoration-none" href="javascript:void(0)"
                aria-expanded="false" title="Laporan"><i class="bi bi-file-earmark-text-fill"></i><span
                    class="hide-menu">Laporan
                </span></a>
            <ul aria-expanded="false" class="collapse first-level">
                <li class="sidebar-item">
                    <a href="/pembelian" class="sidebar-link ms-4" title="Pembelian"><i
                            class="bi bi-cash-stack"></i><span class="hide-menu"> Pembelian
                        </span></a>
                </li>
                <li class="sidebar-item">
                    <a href="/penjualan" class="sidebar-link ms-4" title="Penjualan"><i
                            class="bi bi-cash-coin"></i><span class="hide-menu"> Penjualan </span></a>
                </li>
            </ul>
        </li>
        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" title="Kain"
                href="/kain" aria-expanded="false"><i class="bi bi-collection-fill"></i> <span
                    class="hide-menu">Kain</span></a>
        </li>
        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" title="Kolega"
                href="/kolega" aria-expanded="false"><i class="bi bi-person-vcard-fill"></i> <span
                    class="hide-menu">Kolega</span></a>
        </li>
        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-dark sidebar-link text-decoration-none" title="Konsumen"
                href="barang.html" aria-expanded="false"><i class="bi bi-person-lines-fill"></i><span
                    class="hide-menu">Konsumen</span></a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
            <li class="sidebar-item">
                <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" title="Pengguna"
                    href="/pengguna" aria-expanded="false"><i class="bi bi-people-fill"></i><span
                        class="hide-menu">Pengguna</span></a>
            </li>
        <?php endif; ?>


    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/layout/nav.blade.php ENDPATH**/ ?>