<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
        <?php echo e($title); ?>

    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title"><?php echo e($title); ?></h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <div class="card-body">
                    <div class="mb-3">
                        <?php if(session()->has('gagal')): ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                <b><i class="bi bi-exclamation-triangle-fill"></i></b> <?php echo e(session('gagal')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(auth()->user()->status == 'admin' || auth()->user()->status == 'marketing'): ?>
                            <a class="btn btn-primary" title="Tambah data" href="/penjualan/create" role="button"><i
                                    class="bi bi-bookmark-plus"></i> Tambah</a>
                            <button type="button" class="btn btn-secondary" data-bs-toggle="modal"
                                data-bs-target="#suratJalan"><i class="bi bi-card-text"></i> Surat Jalan
                            </button>
                        <?php endif; ?>
                        <button type="button" class="btn btn-info" data-bs-toggle="modal"
                            data-bs-target="#cetakPenjualan" title="Laporan penjualan"><i
                                class="bi bi-file-earmark-text-fill"></i>
                            Laporan
                        </button>
                    </div>

                    <table id="autoTabel" class="table table-striped table-bordered border-dark">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th width="3%" class="text-white">No</th>
                                <th width="10%" class="text-white">Tanggal</th>
                                <th width="15%" class="text-white">Kain</th>
                                <th width="15%" class="text-white">Harga</th>
                                <th width="5%" class="text-white">Jumlah</th>
                                <th width="17%" class="text-white">Pembeli</th>
                                <th width="15%" class="text-white">Pencatat</th>
                                <th width="20%" class="text-white">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $jml = 0;
                            ?>
                            <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e(tanggal($item->tgl)); ?></td>
                                    <td><?php echo e($item->kain->nama_kain); ?></td>
                                    <td class="text-end"><?php echo e(rupiah($item->harga)); ?></td>
                                    <td class="text-end"><?php echo e($item->jumlah); ?> m<sup>2</sup></td>
                                    <td><?php echo e($item->nama_pembeli); ?></td>
                                    <td><?php echo e($item->pengguna->nama); ?></td>
                                    <td>
                                        <?php if(auth()->user()->status == 'admin' || auth()->user()->status == 'marketing'): ?>
                                            <a href="/penjualan/<?php echo e($item->id_penjualan); ?>/edit" title="Edit data"
                                                class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                            <form action="/penjualan/<?php echo e($item->id_penjualan); ?>" method="post"
                                                class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                        class="bi bi-trash-fill"></i></button>
                                            </form>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                            data-bs-target="#detail<?php echo e($item->id_penjualan); ?>" title="Detail">
                                            <i class="bi bi-card-list"></i>
                                        </button>
                                    </td>
                                </tr>
                                <div class="modal fade" id="detail<?php echo e($item->id_penjualan); ?>" tabindex="-1"
                                    data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                    aria-labelledby="modalTitleId" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md"
                                        role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalTitleId">Detail penjualan</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-4">Pembeli</div>
                                                    <div class="col-8">: <?php echo e($item->nama_pembeli); ?></div>
                                                    <div class="col-4">Tanggal</div>
                                                    <div class="col-8">: <?php echo e(tanggal($item->tgl)); ?></div>
                                                    <div class="col-4">Nama kain</div>
                                                    <div class="col-8">: <?php echo e($item->kain->nama_kain); ?></div>
                                                    <div class="col-4">Harga</div>
                                                    <div class="col-8">: <?php echo e(rupiah($item->harga)); ?></div>
                                                    <div class="col-4">Quantity</div>
                                                    <div class="col-8">: <?php echo e($item->jumlah); ?> m<sup>2</sup></div>
                                                    <div class="col-4">Total bayar</div>
                                                    <div class="col-8">:
                                                        <?php echo e(rupiah($item->jumlah * $item->harga)); ?></div>
                                                    <div class="col-4">Pencatat transaksi</div>
                                                    <div class="col-8">: <?php echo e($item->pengguna->nama); ?></div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    $jml += $item->jumlah * $item->harga;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <h5>Total keseluruhan : <?php echo e(rupiah($jml)); ?> </h5>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
</div>

<!-- Surat jalan -->
<div class="modal fade" id="suratJalan" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
    role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitleId">Surat jalan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/penjualan/suratJalan" method="post" target="_blank">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="nama_pembeli">Nama pembeli</label>
                        <select class="form-select" name="nama_pembeli" id="nama_pembeli" required="required">
                            <option value="" selected hidden disabled>-Pembeli-</option>
                            <?php $__currentLoopData = $pembeli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($i['nama_pembeli']); ?>"><?php echo e($i['nama_pembeli']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-floating mb-3">
                        <textarea class="form-control" placeholder="alamat" name="alamat" id="alamat" required style="height: 100px"></textarea>
                        <label for="alamat">Alamat</label>
                    </div <div class="input-group mb-3">
                    <div class="form-floating mb-3">
                        <input type="date" name="awal" class="form-control " id="awal"
                            placeholder="Tanggal awal">
                        <label for="awal">Tanggal awal</label>
                    </div>
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="jalan">jalan</label>
                        <select class="form-select" name="jalan" id="jalan" required="required">
                            <option value="" selected hidden disabled>-Petugas-</option>
                            <?php
                                $no = 0;
                            ?>
                            <?php $__currentLoopData = $jalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($no++); ?>"><?php echo e($item['supir']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <button type="submit" class="btn btn-primary">Cetak</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Optional: Place to the bottom of scripts -->
<script>
    const myModal = new bootstrap.Modal(document.getElementById('suratJalan'), options)
</script>
<div class="modal fade" id="cetakPenjualan" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
    role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitleId">Laporan penjualan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/penjualan/print" method="post" target="_blank">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="input-group mb-3">
                        <div class="form-floating mb-3">
                            <input type="date" name="awal" class="form-control " id="awal"
                                placeholder="Tanggal awal">
                            <label for="awal">Tanggal awal</label>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <div class="form-floating mb-3">
                            <input type="date" name="akhir" class="form-control " id="akhir"
                                placeholder="Tanggal akhir">
                            <label for="akhir">Tanggal akhir</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Reset</button>
                    <button type="submit" class="btn btn-primary">Print</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startComponent('components.footer'); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/penjualan/penjualan.blade.php ENDPATH**/ ?>