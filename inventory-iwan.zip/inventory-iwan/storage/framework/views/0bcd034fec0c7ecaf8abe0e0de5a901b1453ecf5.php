<h1>hello world</h1>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/hallo.blade.php ENDPATH**/ ?>