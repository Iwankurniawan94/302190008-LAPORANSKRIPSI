

<?php $__env->startSection('main'); ?>
    <h2>ini di kain/tambah kain</h2>
    <form action="/kain" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" name="tes" id="">
        <input type="file" name="gambarSebelum" id="">
        <input type="file" name="gambarSesudah" id="">
        <input type="submit" value="simpan">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-iwan\resources\views/user/kain/kainTambah.blade.php ENDPATH**/ ?>