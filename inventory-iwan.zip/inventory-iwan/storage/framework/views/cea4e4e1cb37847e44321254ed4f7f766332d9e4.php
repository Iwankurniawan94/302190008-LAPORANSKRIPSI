<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="keywords" content="template inventory" />
    <meta name="description" content="inv3ntory" />
    <meta name="robots" content="noindex,nofollow" />
    <title><?php echo e($title); ?></title>
    <!-- Favicon icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <link href="/css/style.min.css" rel="stylesheet" />
    <style>
        table#autoTabel thead tr th,
        table thead th {
            text-align: center;
            color: white;
        }
    </style>
</head>

<body>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <header class="topbar bg-danger" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <a class="navbar-brand" href="/dashboard">
                        <!-- Logo icon -->
                        <b class="logo-icon ps-2">
                            <img src="/img/logo-icon.png" alt="homepage" class="light-logo" width="25" />
                        </b>
                        <span class="logo-text ms-2 mt-3">
                            <!-- dark Logo text -->
                            <h4>INVENTORY</h4>
                        </span>
                    </a>
                </div>

                <?php
                    if (auth()->user()->status == 'admin') {
                        $bg = 'bg-danger';
                    } elseif (auth()->user()->status == 'marketing') {
                        $bg = 'bg-info';
                    } else {
                        $bg = 'bg-success';
                    }
                ?>
                <div class="navbar-collapse collapse <?php echo e($bg); ?> shadow" id="XXnavbarSupportedContent"
                    data-navbarbg="skin5">
                    <ul class="navbar-nav float-start" style="margin-right: 80%">
                        <li class="nav-item d-none d-lg-block">
                            <a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)"
                                data-sidebartype="mini-sidebar"><i class="bi bi-list font-24"></i></a>
                        </li>

                    </ul>
                    <div class="dropdown ">
                        <a class="nav-link dropdown-toggle waves-effect waves-dark pro-pic text-white" href="#"
                            id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="https://e7.pngegg.com/pngimages/178/595/png-clipart-user-profile-computer-icons-login-user-avatars-monochrome-black.png"
                                alt="user" class="rounded-circle me-1" width="31" />
                            <?php echo e(minKata(auth()->user()->nama, 15)); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <form action="/logout" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="dropdown-item"><i class="bi bi-box-arrow-right me-1 ms-1"></i>
                                        logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>

                </div>
            </nav>
        </header>

        <aside class="left-sidebar bg-darkxx shadow" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav','data' => []]); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <main>
            <div class="page-wrapper shadow">
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/components/header.blade.php ENDPATH**/ ?>