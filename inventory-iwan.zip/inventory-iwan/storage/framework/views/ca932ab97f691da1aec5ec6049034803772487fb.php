<!doctype html>
<html lang="en">

<head>
    <title><?php echo e($title); ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        tr th {
            text-align: center;
            padding: 5px;
        }

        td {
            padding: 5px;
        }

        h2 {
            margin-top: 20px;
        }

        table {
            width: 100%;
        }

        @media  print {
            main {
                font-size: 7pt;
            }

            h2 {
                margin-top: 0;
            }

            #print {
                display: none;
            }


        }
    </style>
</head>

<body>
    <div class="bg-dark">
        <div class="container text-end">
            <button id="print" class="btn btn-info my-3">Cetak</button>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/components/headerPrint.blade.php ENDPATH**/ ?>