<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="keywords" content="template inventory" />
    <meta name="description" content="inv3ntory" />
    <meta name="robots" content="noindex,nofollow" />
    <title><?php echo e($title); ?></title>
    <!-- Favicon icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <link href="/css/style.min.css" rel="stylesheet" />
</head>

<body>
    
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <a class="navbar-brand" href="/dashboard">
                        <!-- Logo icon -->
                        <b class="logo-icon ps-2">
                            <img src="/img/logo-icon.png" alt="homepage" class="light-logo" width="25" />
                        </b>
                        <span class="logo-text ms-2">
                            <!-- dark Logo text -->
                            <img src="/img/logo-text.png" alt="homepage" class="light-logo" />
                        </span>
                    </a>
                </div>

                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav float-start me-auto">
                        <li class="nav-item d-none d-lg-block">
                            <a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)"
                                data-sidebartype="mini-sidebar"><i class="bi bi-list font-24"></i></a>
                        </li>

                    </ul>
                    <div class="dropdown "><a
                            class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="#"
                            id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="https://e7.pngegg.com/pngimages/178/595/png-clipart-user-profile-computer-icons-login-user-avatars-monochrome-black.png"
                                alt="user" class="rounded-circle me-1" width="31" />
                            <?php echo e(auth()->user()->nama); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <form action="/logout" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="dropdown-item"><i class="bi bi-box-arrow-right me-1 ms-1"></i>
                                        logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>

                </div>
            </nav>
        </header>

        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <?php echo $__env->make('user/layout/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <main>
            <div class="page-wrapper">
                <?php echo $__env->yieldContent('main'); ?>
                <footer class="footer text-center h6 text-black">
                    &copy; Inventory <?php echo e(date('Y')); ?>

                </footer>
            </div>
        </main>
        <!-- Bootstrap JavaScript Libraries -->
        <script src="/js/jquery.min.js"></script>

        <script src="/js/bootstrap.bundle.min.js"></script>
        <!-- slimscrollbar scrollbar JavaScript -->
        <script src="/js/perfect-scrollbar.jquery.min.js"></script>
        <!--Wave Effects -->
        <script src="/js/waves.js"></script>
        <!--Menu sidebar -->
        <script src="/js/sidebarmenu.js"></script>
        <!--Custom JavaScript -->
        <script src="/js/custom.min.js"></script>

        <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#autoTabel').DataTable();
            });
        </script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script type="text/javascript">
            $('.show_confirm').click(function(event) {
                let form = $(this).closest("form");
                let name = $(this).data("name");
                event.preventDefault();

                Swal.fire({
                    title: 'Yakin hapus data ?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        </script>

</html>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/user/layout/layout.blade.php ENDPATH**/ ?>