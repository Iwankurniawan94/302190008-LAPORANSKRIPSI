<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
        <?php echo e($title); ?>

    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title"><?php echo e($title); ?></h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <div class="card-body">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                        <a class="btn btn-primary mb-3" title="Tambah data" href="/penyimpanan/create" role="button"><i
                                class="bi bi-bookmark-plus"></i> Tambah</a>
                    <?php endif; ?>
                    <table id="autoTabel" class="table table-striped table-bordered border-dark">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th width="5%" class="text-white">No</th>
                                <th width="25%" class="text-white">Palet</th>
                                <th width="15%" class="text-white">Gedung</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                    <th width="15%" class="text-white">Pilihan</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($k->palet); ?></td>
                                    <td><?php echo e($k->gedung); ?></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                        <td>
                                            <a href="/penyimpanan/<?php echo e($k->id_penyimpanan); ?>/edit" title="Edit data"
                                                class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                            <form action="/penyimpanan/<?php echo e($k->id_penyimpanan); ?>" method="post"
                                                class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                        class="bi bi-trash-fill"></i></button>
                                            </form>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Card -->
        </div>
    </div>
</div>
<?php $__env->startComponent('components.footer'); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/penyimpanan/penyimpanan.blade.php ENDPATH**/ ?>