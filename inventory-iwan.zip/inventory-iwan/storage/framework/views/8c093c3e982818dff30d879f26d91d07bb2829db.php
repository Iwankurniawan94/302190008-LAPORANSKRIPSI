<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.headerPrint','data' => []]); ?>
<?php $component->withName('headerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
        <?php echo e($title); ?>

    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="container">
    <header class="pb-2 position-relative">
        <img src="/img/logo-kwangjin.png" width="75px" alt="Logo Inventori" class="position-absolute">
        <h2 class="text-center pt-4">Data Pembelian Kain</h2>
    </header>
    <div class="border-top border-2 border-dark mb-3"></div>
    <main>
        <table class="table-bordered border-1 border-dark">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>No </th>
                    <th>Tanggal</th>
                    <th>Pembeli</th>
                    <th>Kain</th>
                    <th>Qty</th>
                    <th>Harga</th>
                    <th>Total</th>
                    <th>Pencatat</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $jml = 0;
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td class="text-end"><?php echo e(tanggal($item->tgl)); ?></td>
                        <td><?php echo e($item->kolega->nama_kolega); ?></td>
                        <td><?php echo e($item->kain->nama_kain); ?></td>
                        <td class="text-end"><?php echo e(rupiah($item->harga_beli)); ?></td>
                        <td class="text-end"><?php echo e($item->jumlah); ?></td>
                        <td class="text-end"><?php echo e(rupiah($item->jumlah * $item->harga_beli)); ?></td>
                        <td><?php echo e($item->pengguna->nama); ?></td>
                    </tr>
                    <?php
                        $jml += $item->jumlah * $item->harga_beli;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th></th>
                    <th colspan="5">Total Keseluruhan</th>
                    <th class="text-end"><?php echo e(rupiah($jml)); ?></th>
                    <th></th>
                </tr>
            </tbody>
        </table>

    </main>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footerPrint','data' => []]); ?>
<?php $component->withName('footerPrint'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/pembelian/pembelianPrint.blade.php ENDPATH**/ ?>