

<?php $__env->startSection('main'); ?>
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h2 class="page-title">Data Kain</h2>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card rounded-3 shadow-sm">
                    <div class="card-body">
                        <h3 class="text-center">Tabel Data Kain</h3>
                        <div class=" border-top border-secondary pb-3"></div>
                        <?php if(session()->has('pesan')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                <i class="bi bi-check-lg"></i> <?php echo e(session('pesan')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                            <a class="btn btn-primary mb-3" title="Tambah data" href="/kain/create" role="button"><i
                                    class="bi bi-bookmark-plus"></i> Tambah</a>
                        <?php endif; ?>
                        <table id="autoTabel" class="table table-striped table-bordered border-dark">
                            <thead class="bg-primary text-white">
                                <tr>
                                    <th width="3%" class="text-white">No</th>
                                    <th width="20%" class="text-white">Nama kain</th>
                                    <th width="15%" class="text-white">Harga jual</th>
                                    <th width="10%" class="text-white">Stok</th>
                                    <th width="20%" class="text-white">Gambar sebelumnya</th>
                                    <th width="20%" class="text-white">Gambar sesudahnya</th>
                                    <th width="12%" class="text-white">Pilihan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($k->nama_kain); ?></td>
                                        <td class="text-end"><?php echo e('Rp ' . number_format($k->harga, 2, ',', '.')); ?> /pcs</td>
                                        <td class="text-end"><?php echo e($k->jumlah); ?> pcs</td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/' . $k->foto_sebelum)); ?>"
                                                alt="<?php echo e($k->foto_sebelum); ?>" width='150'>
                                        </td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/' . $k->foto_sesudah)); ?>"
                                                alt="<?php echo e($k->foto_sesudah); ?>" width="150">
                                        </td>
                                        <td>
                                            <a href="/kain/<?php echo e($k->id_kain); ?>/edit" title="Edit data"
                                                class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                            <form action="/kain/<?php echo e($k->id_kain); ?>" method="post" class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                        class="bi bi-trash-fill"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Card -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/user/kain/kain.blade.php ENDPATH**/ ?>