<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
        <?php echo e($title); ?>

    <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-12 d-flex no-block align-items-center">
            <h2 class="page-title"><?php echo e($title); ?></h2>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card rounded-3 shadow-sm">
                <div class="card-body">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                        <a class="btn btn-primary mb-3" title="Tambah data" href="/kain/create" role="button"><i
                                class="bi bi-bookmark-plus"></i> Tambah</a>
                    <?php endif; ?>
                    <table id="autoTabel" class="table table-striped table-bordered border-dark">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th width="3%">No</th> 
                                <th width="15%">Nama kain</th>
                                <th width="15%">Harga jual</th>
                                <th width="10%">Stok</th>
                                <th width="20%">Gambar sebelumnya</th>
                                <th width="20%">Gambar sesudahnya</th>
                                <th width="17%">Pilihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($k->nama_kain); ?></td>
                                    <td class="text-end"><?php echo e(rupiah($k->harga)); ?> /m<sup>2</sup></td>
                                    <td class="text-end"><?php echo e($k->jumlah); ?> m<sup>2</sup></td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/gambar-sebelum/' . $k->foto_sebelum)); ?>"
                                            alt="<?php echo e($k->foto_sebelum); ?>" title="<?php echo e($k->desc_foto_sebelum); ?>"
                                            width='150'>
                                    </td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/gambar-sesudah/' . $k->foto_sesudah)); ?>"
                                            alt="<?php echo e($k->foto_sesudah); ?>" title="<?php echo e($k->desc_foto_sesudah); ?>"
                                            width="150">
                                    </td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                            <a href="/kain/<?php echo e($k->id_kain); ?>/edit" title="Edit data"
                                                class="btn btn-warning "><i class="bi bi-pencil-square"></i></a>
                                            <form action="/kain/<?php echo e($k->id_kain); ?>" method="post" class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button title="Hapus data" class="btn btn-danger show_confirm"><i
                                                        class="bi bi-trash-fill"></i></button>
                                            </form>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                            data-bs-target="#detail<?php echo e($k->id_kain); ?>" title="Detail">
                                            <i class="bi bi-card-list"></i>
                                        </button>
                                    </td>
                                </tr>
                                <div class="modal fade" id="detail<?php echo e($k->id_kain); ?>" tabindex="-1"
                                    data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
                                    aria-labelledby="modalTitleId" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md"
                                        role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalTitleId">Detail kain</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-4">Nama kain</div>
                                                    <div class="col-8">: <?php echo e($k->nama_kain); ?></div>
                                                    <div class="col-4">Harga</div>
                                                    <div class="col-8">: <?php echo e(rupiah($k->harga)); ?> /m<sup>2</sup></div>
                                                    <div class="col-4">Jumlah kain</div>
                                                    <div class="col-8">: <?php echo e($k->jumlah); ?> m<sup>2</sup></div>
                                                    <div class="col-4">Palet penyimpanan</div>
                                                    <div class="col-8">: <?php echo e($k->penyimpanan->palet); ?></div>
                                                    <div class="col-4">Gedung</div>
                                                    <div class="col-8">: <?php echo e($k->penyimpanan->gedung); ?></div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div> <!-- Card -->
        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/home/kain/kain.blade.php ENDPATH**/ ?>