<nav class="sidebar-nav">
    <ul id="sidebarnav" class="pt-4">
        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" href="/dashboard"
                aria-expanded="false"><i class="bi bi-house-fill"></i><span class="hide-menu">Dashboard</span></a>
        </li>
        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" href="/kain"
                aria-expanded="false"><i class="bi bi-collection-fill"></i> <span class="hide-menu">Kain</span></a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
            <li class="sidebar-item">
                <a class="sidebar-link waves-effect waves-white sidebar-link text-decoration-none" href="/pengguna"
                    aria-expanded="false"><i class="bi bi-people-fill"></i><span class="hide-menu">Pengguna</span></a>
            </li>
        <?php endif; ?>

        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-dark sidebar-link text-decoration-none" href="barang.html"
                aria-expanded="false"><i class="bi bi-columns"></i><span class="hide-menu">Barang</span></a>
        </li>
        <li class="sidebar-item">
            <a class="sidebar-link has-arrow waves-effect waves-dark text-decoration-none" href="javascript:void(0)"
                aria-expanded="false"><span class="hide-menu">Forms
                </span></a>
            <ul aria-expanded="false" class="collapse first-level">
                <li class="sidebar-item">
                    <a href="form-basic.html" class="sidebar-link"><span class="hide-menu"> Form
                            Basic
                        </span></a>
                </li>
                <li class="sidebar-item">
                    <a href="form-wizard.html" class="sidebar-link"><span class="hide-menu"> Form
                            Wizard </span></a>
                </li>
            </ul>
        </li>
        <li class="sidebar-item">
            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="pages-elements.html"
                aria-expanded="false"><span class="hide-menu">Elements</span></a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\Temen\inventory-iwan\resources\views/user/layout/nav.blade.php ENDPATH**/ ?>