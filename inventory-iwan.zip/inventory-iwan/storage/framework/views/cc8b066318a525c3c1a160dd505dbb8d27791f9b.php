<!doctype html>
<html lang="en">

<head>
    <title><?php echo e($title); ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

</head>

<body>
    <header>
        <h1 class="text-center text-danger"><?php echo e($desc); ?></h1>
    </header>
    <main>
        <div class="row justify-content-center">
            <div class="col-md-4">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session()->has('gagal')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('gagal')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <main class="form-signin">

                    <form action="/login" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="username">
                        <input type="text" name="password">
                        <button type="submit" class="w-100 btn btn-lg btn-primary mt-3">Login</button>
                    </form>
                    <small class="d-block text-center mt-3">Not registered? <a href="/register">Register now</a></small>
                </main>
            </div>
        </div>
    </main>
    <footer>
        <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    
    <script src="js/bootstrap.bunble.min.js"></script>

    <script src="js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\inventory-iwan\resources\views/global/home.blade.php ENDPATH**/ ?>