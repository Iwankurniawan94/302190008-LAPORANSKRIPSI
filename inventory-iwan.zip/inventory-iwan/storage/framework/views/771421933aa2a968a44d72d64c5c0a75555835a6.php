

<?php $__env->startSection('main'); ?>
    <h2>ini kain/lain.blade</h2>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <a href="/kain/create">tambah</a>
    <?php endif; ?>

    <table>
        <tr>
            <th></th>
        </tr>
        <?php $__currentLoopData = $kain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($k->nama_kain); ?></td>
                <td>
                    <img width="100" src="<?php echo e(asset('storage/gambar-sebelum/sebelum.png')); ?>" alt="" srcset="">
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-iwan\resources\views/user/kain/kain.blade.php ENDPATH**/ ?>